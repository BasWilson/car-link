import 'package:flutter/widgets.dart';

final Color justPurple = const Color(0xFF845EC2);
final Color neatTeal = const Color(0xFF00C9A7);
final Color blindingGreen = const Color(0xFFC4FCEF);
final Color poopGreen = const Color(0xFF4D8076);