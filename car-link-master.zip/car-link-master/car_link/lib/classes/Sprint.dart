class Sprint {
  DateTime zeroTime, maxTime;
}