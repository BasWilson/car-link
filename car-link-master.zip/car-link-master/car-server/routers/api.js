const express = require('express');
const router = express.Router();
const api = require('../modules/api');

// define the home page route
router.get('/', function (req, res) {
    res.send('API is up and running');
});

router.post('/linkCar', function (req, res) {
    api.linkCar(req.body).then((result) => {
        console.log('Saved car:', result);
        res.send(result);
    });
});

router.post('/createUser', function (req, res) {
    api.createUser(req.body).then((result) => {
        console.log('Saved user:', result);
        res.send(result);
    });
});


router.post('/updateCar', function (req, res) {
    api.updateCar(req.body).then((result) => {
        console.log('Updated car:', result);
        res.send(result);
    });
});

module.exports = router;