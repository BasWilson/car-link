# Introduction
Pyhton program to measure and store car events. 
Made as a link for car-link app

# Installation
pip install obd
pip install requests

# Quick start
Setup the options.py file to your needs. Make sure the username and pincode match the ones you set within the car-link app.