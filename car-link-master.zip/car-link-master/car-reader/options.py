mockMode = True # Set to true if testing out without car connection
maxSprintTime = 15 # Maxiumum amount of seconds it may take to do a 0 - 100 sprint
carLinkUrl = 'http://localhost:4000/api'
carLinkUsername = 'yourusername' # Set to same username you have used to setup car link on your phone
carLinkPinCode = '0000' # Set to same pincode you have used to setup car link on your phone