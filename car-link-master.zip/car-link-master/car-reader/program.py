import obd
import time
import options
import data.connection
from measurements.sprints import measureSprint

# Set true if not connected to car
running = False

# Enable all debug information
obd.logger.setLevel(obd.logging.DEBUG)

connection = None

# Connect to elm327 plug
try:
    connection = obd.OBD() # auto-connects to USB or RF port
except:
    print("Could not connect to ELM327 plug")

# Stop logging after connection made
obd.logger.removeHandler(obd.console_handler)

if connection != None:
    running = True
elif options.mockMode == True:
    print("Running in MOCK MODE")
    running = True

while running == True:
    time.sleep( .8 )
    nullToHundred = measureSprint(connection)